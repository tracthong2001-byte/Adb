# Local ADB Manager 1.0.2 — sửa kết nối Xiaomi (chưa test trên thiết bị thật)

## Vấn đề
Bản 1.0.1 cố định địa chỉ 127.0.0.1 khi ghép đôi và kết nối. Trên Xiaomi adbd có thể chỉ lắng nghe trên IPv4 của Wi-Fi; vì vậy báo ECONNREFUSED.

## Thay đổi
- Lấy IPv4 từ ConnectivityManager/Wi-Fi, có ô nhập IP thủ công (IP từ Wireless debugging).
- Gọi pair(host, pairingPort, code), connect(host, connectionPort).
- Phát hiện IP + cổng ghép đôi qua mDNS khi ROM hỗ trợ; auto TLS/mDNS giữ nguyên và thêm fallback kết nối IP/cổng thủ công nếu đã điền.
- Không thay đổi cơ chế xác nhận hệ thống; không tự động chấp nhận thông báo Android.

## Hướng dẫn Mi 10S
1. Bật Wireless debugging, dùng Wi-Fi (không phải 4G).
2. Mở Pair device with pairing code rồi ghi IP, pairing port và mã sáu số MỚI.
3. Chuyển đến Local ADB Manager, chọn ADB, nhập IP Wi-Fi cùng pairing port và mã sáu số, bấm Ghép đôi bằng IP Wi-Fi.
4. Quay về Wireless debugging (màn hình chính) xem IP address & Port; cổng này KHÁC pairing port.
5. Nhập cổng kết nối ở mục 2 và bấm Kết nối bằng IP và cổng thủ công.
6. Bấm Kiểm tra quyền ADB (id) để xác nhận lệnh shell thực sự chạy.

Lưu ý: mã pairing có thời hạn, 2 cổng đều thay đổi khi tắt/bật Wireless debugging; một số ROM có chặn kết nối chính nó qua IP Wi-Fi.

## Build
Giữ tên ZIP LocalADB-Manager-Android-Source.zip ở thư mục gốc của repository; workflow hiện tại sẽ tự build khi tệp này được commit. Không có APK đi kèm ZIP này.
