# Tạo APK cài trực tiếp — Local ADB Manager 1.0.1

**Hiện trạng:** Chưa tạo APK trong môi trường này vì không có Android SDK và Gradle; chưa xác nhận thành công trên Xiaomi MIUI.

## Cách build bằng GitHub Actions

1. Tạo repository GitHub **riêng tư** (private).
2. Upload tất cả nội dung **trong** thư mục `LocalADB-Manager` lên gốc repository, giữ nguyên `.github/workflows/build-apk.yml`.
3. Mở tab **Actions → Build Android APK → Run workflow**.
4. Đợi workflow báo **Success**. Mở run → **Artifacts → LocalADBManager-debug-apk**.
5. Giải nén artifact để có `app-debug.apk` và `app-debug.apk.sha256`.
6. Chuyển APK sang Xiaomi, cho phép nguồn cài đặt đáng tin cậy với ứng dụng đang mở APK, rồi chấp nhận màn hình trình cài đặt hệ thống.

LƯU Ý: Đây là **debug-signed APK** phù hợp thử nghiệm, không phải bản production ký bằng khóa phát hành cá nhân.

## Khi build lỗi

- Mở tab Actions, chọn run lỗi và gửi log bước **Build installable debug APK**.
- Kiểm tra mạng Maven/JitPack (thư viện ADB tải từ JitPack) và Android SDK có được tải trên máy build.

## Dùng trên điện thoại

1. Vào Settings → Developer Options → Wireless debugging.
2. Chọn Pair device with pairing code, lấy **cổng pairing** cùng mã 6 số.
3. Trong app → ADB → nhập cổng và mã → ghép đôi.
4. Vào Settings → Wireless debugging xem **cổng kết nối** riêng, nhập và connect (hoặc dùng auto discovery).
5. Vào tab Apps → chọn app → chọn lệnh `pm grant` hoặc AppOps. Đọc kết quả lệnh, ROM có thể từ chối.

**Không thể tự bật Wireless debugging hoặc tự xác nhận ghép đôi lần đầu, và không thể tự chấp thuận tất cả quyền bảo mật.**
