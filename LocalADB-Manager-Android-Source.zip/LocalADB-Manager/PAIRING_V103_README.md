# Local ADB Manager 1.0.3 — Ghép đôi ngay trong Cài đặt, không cần chuyển app

Bản v1.0.3 bổ sung PairingService (foreground service) + PairingAccessibilityService (tùy chọn):

1. Mở app → ADB → tự lấy/điền IP Wi-Fi.
2. **Tùy chọn:** Nhấn **BẬT chế độ tự đọc mã**, chọn Local ADB Manager trong Accessibility, bật quyền nếu bạn đồng ý.
3. Quay về app → ADB → **BẮT ĐẦU ghép đôi qua thông báo / tự đọc**. Cho phép thông báo khi Android hỏi. App sẽ mở phần Gỡ lỗi không dây / Tùy chọn nhà phát triển.
4. Trong Cài đặt → Gỡ lỗi không dây → **Ghép đôi thiết bị bằng mã ghép đôi**. **GIỮ HỘP THOẠI NÀY TRÊN MÀN HÌNH**.
5. Nếu Xiaomi cho phép Accessibility đọc nội dung Settings, app tự nhận mã, IP, cổng ghép đôi, gửi pairing và thử kết nối. Nếu không, kéo thanh thông báo xuống, mở thông báo **Local ADB Manager → Nhập mã ghép đôi** rồi nhập sáu chữ số trong cửa sổ Cài đặt. Không phải quay lại màn hình app.
   - Nếu mDNS không tự tìm ra cổng ghép đôi, nhập cả `CỔNG MÃ` trong cùng dòng. Ví dụ `41001 123456` là dữ liệu MẪU CHỈ để minh họa, phải thay bằng dữ liệu mới đang hiển thị trên điện thoại.
6. Sau khi pairing thành công, app tự thử tìm ADB TLS connect qua mDNS, rồi thử cổng kết nối đã đọc từ trang Settings. Nếu Xiaomi chặn mDNS, quay về app → ADB → nhập cổng **KẾT NỐI** như `41002` (cổng thay đổi theo phiên) → **Kết nối bằng IP và cổng thủ công**.

### Giới hạn

- Android không có API thông thường để lấy mã ghép đôi 6 số. Tự đọc chỉ chạy nếu bạn chủ động bật Accessibility và ROM cho phép đọc thông tin trên cửa sổ Settings.
- Dịch vụ Accessibility **chỉ đọc gói** `com.android.settings`; chỉ lấy mã khi cửa sổ ghép đôi xuất hiện trong **10 phút** sau khi bạn bấm BẮT ĐẦU. Không tự bấm vào Cài đặt, không bấm chấp thuận, không chụp màn hình, không lưu mã ra đĩa, không gửi mã ra mạng. Mã chỉ gửi trực tiếp cho ADB daemon của điện thoại qua Wi-Fi LAN.
- Nếu ROM ngăn thông báo hiển thị trên Android 13+, phải cấp quyền thông báo trước; chế độ nhập mã qua notification có thể không hoạt động nếu Xiaomi hạn chế thanh thông báo trong lúc hộp thoại mở.
- Accessibility là quyền nhạy cảm; chỉ cấp nếu bạn tin ứng dụng, sau khi ghép đôi có thể tắt lại. Ứng dụng cài ngoài Play Store có thể bị hệ thống chặn quyền Accessibility cho đến khi người dùng bật "Allow restricted settings" trong trang thông tin ứng dụng. Không cố vượt qua bước xác nhận đó.
- Cổng **GHÉP ĐÔI** và **KẾT NỐI** khác nhau; không dùng cổng ghép đôi để kết nối. Hai cổng có thể thay đổi mỗi lần mở Wireless debugging.
- Đây là mã nguồn phiên bản thử nghiệm, chưa biên dịch/kiểm thử trên máy Mi 10S thực tế.

### GitHub repo cũ

Workflow trong `tracthong2001-byte/Adb` chờ tệp `LocalADB-Manager-Android-Source.zip` ở thư mục gốc. Khi thay ZIP cùng tên bằng tệp đi kèm bản này, workflow sẽ giải nén `LocalADB-Manager` và build bằng Gradle. Kết quả nếu thành công nằm ở **Actions → run mới → Artifacts → LocalADBManager-debug-apk**, trong đó có `app-debug.apk`.
