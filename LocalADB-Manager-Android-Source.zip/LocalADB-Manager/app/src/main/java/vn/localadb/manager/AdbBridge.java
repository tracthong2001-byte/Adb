package vn.localadb.manager;

import android.content.Context;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.math.BigInteger;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.security.auth.x500.X500Principal;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;

/**
 * Direct local wireless ADB. Credentials are held in Android Keystore.
 * The user MUST enable wireless debugging and approve pairing in Settings.
 */
public final class AdbBridge extends AbsAdbConnectionManager {
    private static final String KEY_ALIAS = "LocalADBManagerWirelessKeyV1";
    private static AdbBridge instance;
    private final PrivateKey privateKey;
    private final Certificate certificate;
    private static final Pattern EXIT_CODE = Pattern.compile("__LOCALADB_RC__:(\\d+)");

    public static synchronized AdbBridge get() throws Exception {
        if (instance == null) instance = new AdbBridge();
        return instance;
    }

    private AdbBridge() throws Exception {
        setApi(Build.VERSION.SDK_INT);
        setHostAddress("127.0.0.1");
        setTimeout(12, TimeUnit.SECONDS);
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (!store.containsAlias(KEY_ALIAS)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                    KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                    .setKeySize(2048)
                    .setCertificateSubject(new X500Principal("CN=Local ADB Manager"))
                    .setCertificateSerialNumber(BigInteger.valueOf(System.currentTimeMillis()))
                    .setCertificateNotBefore(new Date(System.currentTimeMillis() - 86400000L))
                    .setCertificateNotAfter(new Date(System.currentTimeMillis() + 315360000000L))
                    .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                    .build());
            generator.generateKeyPair();
            store.load(null);
        }
        privateKey = (PrivateKey) store.getKey(KEY_ALIAS, null);
        certificate = store.getCertificate(KEY_ALIAS);
        if (privateKey == null || certificate == null) throw new IllegalStateException("Không thể tạo khóa ADB trong Keystore");
    }

    @Override protected PrivateKey getPrivateKey() { return privateKey; }
    @Override protected Certificate getCertificate() { return certificate; }
    @Override protected String getDeviceName() { return "Local ADB Manager"; }

    public boolean pairLocal(int pairingPort, String code) throws Exception {
        if (!code.matches("[0-9]{6}")) throw new IllegalArgumentException("Mã ghép đôi phải gồm 6 chữ số");
        checkPort(pairingPort);
        return pair("127.0.0.1", pairingPort, code);
    }

    public boolean connectLocal(int connectionPort) throws Exception {
        checkPort(connectionPort);
        return connect("127.0.0.1", connectionPort);
    }

    public boolean discoverAndConnect(Context context) throws Exception {
        return connectTls(context, 10000L);
    }

    static void checkPort(int port) {
        if (port < 1024 || port > 65535) throw new IllegalArgumentException("Cổng ADB không hợp lệ");
    }

    /** Never execute user-supplied shell. Commands come only from a fixed allowlist. */
    public CommandResult execute(String approvedCommand) throws Exception {
        if (!isConnected()) throw new IllegalStateException("Cần kết nối ADB trước");
        if (approvedCommand.length() > 512 || approvedCommand.contains("'")
                || approvedCommand.contains("\n") || approvedCommand.contains("\r")) {
            throw new IllegalArgumentException("Lệnh không hợp lệ");
        }
        String destination = "shell:sh -c '" + approvedCommand +
                " 2>&1; echo __LOCALADB_RC__:$?'";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (AdbStream stream = openStream(destination); InputStream input = stream.openInputStream()) {
            byte[] buffer = new byte[2048];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (out.size() + count > 131072) throw new IllegalStateException("ADB trả về quá nhiều dữ liệu");
                out.write(buffer, 0, count);
            }
        }
        String text = out.toString(StandardCharsets.UTF_8.name());
        Matcher matcher = EXIT_CODE.matcher(text);
        if (!matcher.find()) throw new IllegalStateException("Không nhận được mã kết thúc ADB. Output: " + text);
        int rc = Integer.parseInt(matcher.group(1));
        return new CommandResult(rc, text.replaceAll("__LOCALADB_RC__:[0-9]+", "").trim());
    }

    static String safePackage(String pkg) {
        if (!pkg.matches("[A-Za-z][A-Za-z0-9_.]{2,200}")) throw new IllegalArgumentException("Tên package không hợp lệ");
        return pkg;
    }

    static String safePermission(String permission) {
        if (!permission.matches("[A-Za-z][A-Za-z0-9_.]{2,240}")) throw new IllegalArgumentException("Tên permission không hợp lệ");
        return permission;
    }

    public CommandResult appOp(String pkg, String op, String mode) throws Exception {
        safePackage(pkg);
        if (!PermissionActions.ALLOWED_OPS.contains(op)) throw new IllegalArgumentException("App-op không được hỗ trợ");
        if (!(mode.equals("allow") || mode.equals("ignore") || mode.equals("default")))
            throw new IllegalArgumentException("Chế độ không hợp lệ");
        return execute("appops set " + pkg + " " + op + " " + mode);
    }

    public CommandResult getAppOp(String pkg, String op) throws Exception {
        safePackage(pkg);
        if (!PermissionActions.ALLOWED_OPS.contains(op)) throw new IllegalArgumentException("App-op không được hỗ trợ");
        return execute("appops get " + pkg + " " + op);
    }

    public CommandResult runtimePermission(String pkg, String permission, boolean grant) throws Exception {
        safePackage(pkg);
        safePermission(permission);
        return execute("pm " + (grant ? "grant " : "revoke ") + pkg + " " + permission);
    }

    public static final class CommandResult {
        public final int code;
        public final String text;
        CommandResult(int code, String text) { this.code = code; this.text = text; }
        public boolean success() { return code == 0; }
        @Override public String toString() { return "Exit " + code + (text.isEmpty()? "" : "\n"+text); }
    }
}
