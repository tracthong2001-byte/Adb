package vn.localadb.manager;

import android.content.Context;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.math.BigInteger;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.security.auth.x500.X500Principal;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;

/**
 * Direct local wireless ADB. Credentials are held in Android Keystore.
 * The user MUST enable wireless debugging and approve pairing in Settings.
 */
public final class AdbBridge extends AbsAdbConnectionManager {
    private static final String KEY_ALIAS = "LocalADBManagerWirelessKeyV1";
    private static AdbBridge instance;
    private final PrivateKey privateKey;
    private final Certificate certificate;
    private static final Pattern EXIT_CODE = Pattern.compile("__LOCALADB_RC__:(\\d+)");

    public static synchronized AdbBridge get() throws Exception {
        if (instance == null) instance = new AdbBridge();
        return instance;
    }

    private AdbBridge() throws Exception {
        setApi(Build.VERSION.SDK_INT);
        setTimeout(12, TimeUnit.SECONDS);
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (!store.containsAlias(KEY_ALIAS)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                    KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                    .setKeySize(2048)
                    .setCertificateSubject(new X500Principal("CN=Local ADB Manager"))
                    .setCertificateSerialNumber(BigInteger.valueOf(System.currentTimeMillis()))
                    .setCertificateNotBefore(new Date(System.currentTimeMillis() - 86400000L))
                    .setCertificateNotAfter(new Date(System.currentTimeMillis() + 315360000000L))
                    .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                    .build());
            generator.generateKeyPair();
            store.load(null);
        }
        privateKey = (PrivateKey) store.getKey(KEY_ALIAS, null);
        certificate = store.getCertificate(KEY_ALIAS);
        if (privateKey == null || certificate == null) throw new IllegalStateException("Không thể tạo khóa ADB trong Keystore");
    }

    @Override protected PrivateKey getPrivateKey() { return privateKey; }
    @Override protected Certificate getCertificate() { return certificate; }
    @Override protected String getDeviceName() { return "Local ADB Manager"; }

    /** The daemon on many Xiaomi builds listens on WLAN, not loopback. */
    public boolean pairLocal(String host, int pairingPort, String code) throws Exception {
        if (!code.matches("[0-9]{6}")) throw new IllegalArgumentException("Mã ghép đôi phải gồm 6 chữ số");
        checkPort(pairingPort);
        validateIpv4(host);
        return pair(host, pairingPort, code);
    }

    public boolean connectLocal(String host, int connectionPort) throws Exception {
        checkPort(connectionPort);
        validateIpv4(host);
        return connect(host, connectionPort);
    }

    private static void validateIpv4(String host) {
        if (host == null || !host.matches("[0-9.]{7,15}"))
            throw new IllegalArgumentException("Hãy nhập địa chỉ IPv4 Wi-Fi, ví dụ 192.168.1.159");
        String[] parts = host.split("\\.", -1);
        if (parts.length != 4) throw new IllegalArgumentException("Địa chỉ IP không hợp lệ");
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3)
                throw new IllegalArgumentException("Địa chỉ IP không hợp lệ");
            int octet = Integer.parseInt(part);
            if (octet > 255) throw new IllegalArgumentException("Địa chỉ IP không hợp lệ");
        }
        if (host.startsWith("127."))
            throw new IllegalArgumentException("Dùng IP Wi-Fi trong Gỡ lỗi không dây, không dùng 127.0.0.1");
    }

    public boolean discoverAndConnect(Context context) throws Exception {
        return connectTls(context, 10000L);
    }

    static void checkPort(int port) {
        if (port < 1024 || port > 65535) throw new IllegalArgumentException("Cổng ADB không hợp lệ");
    }

    /**
     * Execute the app's limited package-manager commands over an authenticated ADB shell.
     * A short "shell:sh" service avoids the libadb-android 3.1.1 buffer-overflow issue
     * with long ADB OPEN destination strings (see upstream issue #26).
     */
    public CommandResult execute(String approvedCommand) throws Exception {
        if (!isConnected()) throw new IllegalStateException("Cần kết nối ADB trước");
        // No shell metacharacters in commands. All variable arguments are checked again
        // in safePackage/safePermission and ALLOWED_OPS.
        if (approvedCommand.length() > 512
                || !approvedCommand.matches("[A-Za-z0-9_. -]+")) {
            throw new IllegalArgumentException("Lệnh không hợp lệ");
        }
        String script = approvedCommand
                + " 2>&1; printf '\\n__LOCALADB_RC__:%d\\n' $?; exit\n";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (AdbStream stream = openStream("shell:sh");
             InputStream input = stream.openInputStream()) {
            OutputStream remoteInput = stream.openOutputStream();
            remoteInput.write(script.getBytes(StandardCharsets.UTF_8));
            remoteInput.flush();
            byte[] buffer = new byte[2048];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (out.size() + count > 131072)
                    throw new IllegalStateException("ADB trả về quá nhiều dữ liệu");
                out.write(buffer, 0, count);
            }
        }
        String output = out.toString(StandardCharsets.UTF_8.name());
        Matcher matcher = EXIT_CODE.matcher(output);
        int rc = -1;
        while (matcher.find()) rc = Integer.parseInt(matcher.group(1));
        if (rc == -1) throw new IllegalStateException("Không nhận được mã kết thúc ADB. Output: " + output);
        return new CommandResult(rc, output.replaceAll("__LOCALADB_RC__:[0-9]+", "").trim());
    }

    static String safePackage(String pkg) {
        if (!pkg.matches("[A-Za-z][A-Za-z0-9_.]{2,200}")) throw new IllegalArgumentException("Tên package không hợp lệ");
        return pkg;
    }

    static String safePermission(String permission) {
        if (!permission.matches("[A-Za-z][A-Za-z0-9_.]{2,240}")) throw new IllegalArgumentException("Tên permission không hợp lệ");
        return permission;
    }

    public CommandResult appOp(String pkg, String op, String mode) throws Exception {
        safePackage(pkg);
        if (!PermissionActions.ALLOWED_OPS.contains(op)) throw new IllegalArgumentException("App-op không được hỗ trợ");
        if (!(mode.equals("allow") || mode.equals("ignore") || mode.equals("default")))
            throw new IllegalArgumentException("Chế độ không hợp lệ");
        return execute("appops set " + pkg + " " + op + " " + mode);
    }

    public CommandResult getAppOp(String pkg, String op) throws Exception {
        safePackage(pkg);
        if (!PermissionActions.ALLOWED_OPS.contains(op)) throw new IllegalArgumentException("App-op không được hỗ trợ");
        return execute("appops get " + pkg + " " + op);
    }

    public CommandResult runtimePermission(String pkg, String permission, boolean grant) throws Exception {
        safePackage(pkg);
        safePermission(permission);
        return execute("pm " + (grant ? "grant " : "revoke ") + pkg + " " + permission);
    }

    public static final class CommandResult {
        public final int code;
        public final String text;
        CommandResult(int code, String text) { this.code = code; this.text = text; }
        public boolean success() { return code == 0; }
        @Override public String toString() { return "Exit " + code + (text.isEmpty()? "" : "\n"+text); }
    }
}
