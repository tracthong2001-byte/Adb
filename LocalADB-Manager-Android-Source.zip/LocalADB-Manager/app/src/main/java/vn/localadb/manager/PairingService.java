package vn.localadb.manager;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The user starts this foreground service BEFORE opening the system's pairing dialog.
 * Pairing codes are accepted either via the user's notification reply, or from the
 * opt-in AccessibilityService while the Android Settings dialog remains visible.
 */
public final class PairingService extends Service {
    public static final String ACTION_START = "vn.localadb.manager.START_PAIRING";
    public static final String ACTION_REPLY = "vn.localadb.manager.REPLY_PAIRING";
    public static final String ACTION_PAIR = "vn.localadb.manager.PAIR_WITH_CODE";
    public static final String ACTION_STOP = "vn.localadb.manager.STOP_PAIRING";
    private static final String CHANNEL = "localadb_pairing";
    private static final String EXTRA_REPLY = "localadb_pairing_reply";
    private static final String PREFERENCES = "localadb_pairing_state";
    private static final int ID = 9101;
    private static final long MAX_CAPTURE_MS = 10 * 60 * 1000L;
    private static final Pattern CODE = Pattern.compile("(?:^|\\s)([0-9]{6})(?:\\s|$)");
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;
    private WifiManager.MulticastLock multicastLock;
    private String wifiIp = "";
    private int pairingPort = -1;
    private String queuedCode;
    private volatile boolean busy = false;
    private volatile boolean active = false;

    public static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFERENCES, MODE_PRIVATE);
    }
    public static boolean isArmed(Context context) {
        return prefs(context).getLong("capture_until", 0) > System.currentTimeMillis();
    }
    public static void begin(Context context, String host) {
        Intent i = new Intent(context, PairingService.class).setAction(ACTION_START);
        i.putExtra("host", host);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
        else context.startService(i);
    }
    public static void submitFromAccessibility(Context context, String ip, int port, String code) {
        if (!isArmed(context)) return;
        if (!code.matches("[0-9]{6}")) return;
        Intent i = new Intent(context, PairingService.class).setAction(ACTION_PAIR);
        i.putExtra("host", ip).putExtra("port", port).putExtra("code", code);
        // The service was started in the foreground before opening Settings.
        context.startService(i);
    }

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL,
                    "Ghép đôi ADB cục bộ", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Nhập mã ADB mà không rời Cài đặt Android");
            channel.enableVibration(false);
            manager.createNotificationChannel(channel);
        }
        nsd = (NsdManager) getSystemService(NSD_SERVICE);
        try {
            WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wifiManager != null) {
                multicastLock = wifiManager.createMulticastLock("LocalADBPairingMdns");
                multicastLock.setReferenceCounted(false);
            }
        } catch (Exception e) { Log.w("LocalADBPair", "Multicast unavailable", e); }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // Required immediately for a service started via startForegroundService.
        showForeground("Sẵn sàng nhận mã ghép đôi", true);
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            String ip = intent.getStringExtra("host");
            wifiIp = ip == null ? "" : ip.trim();
            active = true;
            pairingPort = -1;
            queuedCode = null;
            prefs(this).edit().putLong("capture_until", System.currentTimeMillis() + MAX_CAPTURE_MS)
                    .putString("host", wifiIp).apply();
            startDiscovery();
            showForeground("Mở Gỡ lỗi không dây → Ghép đôi bằng mã. Nhập mã trong thông báo hoặc bật tự đọc.", true);
        } else if (ACTION_REPLY.equals(action)) {
            CharSequence reply = null;
            android.os.Bundle results = RemoteInput.getResultsFromIntent(intent);
            if (results != null) reply = results.getCharSequence(EXTRA_REPLY);
            if (reply != null) {
                String answer = reply.toString().trim();
                // User can reply "43293 630891" if Xiaomi blocks mDNS.
                Matcher m = Pattern.compile("^([0-9]{4,5})[ :;,]+([0-9]{6})$").matcher(answer);
                if (m.matches()) {
                    tryPair(wifiIp, Integer.parseInt(m.group(1)), m.group(2));
                } else if (CODE.matcher(answer).matches()) {
                    if (pairingPort > 0) tryPair(wifiIp, pairingPort, answer);
                    else {
                        queuedCode = answer;
                        showForeground("Chưa tìm thấy cổng mDNS. Nhập lại: CỔNG MÃ (ví dụ 43293 630891).", true);
                    }
                } else showForeground("Cần mã 6 số, hoặc nhập theo dạng CỔNG MÃ.", true);
            }
        } else if (ACTION_PAIR.equals(action)) {
            // Recover when Android has recreated the service but the user is still
            // in the explicitly armed ten-minute pairing window.
            if (!active && isArmed(this)) {
                active = true;
                wifiIp = prefs(this).getString("host", "");
            }
            String code = intent.getStringExtra("code");
            String host = intent.getStringExtra("host");
            int port = intent.getIntExtra("port", -1);
            if (code != null && host != null) tryPair(host, port, code);
        } else if (ACTION_STOP.equals(action)) {
            prefs(this).edit().remove("capture_until").apply();
            active = false;
            stopDiscovery();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startDiscovery() {
        stopDiscovery();
        if (nsd == null) return;
        try { if (multicastLock != null && !multicastLock.isHeld()) multicastLock.acquire(); }
        catch (Exception ignored) { }
        discovery = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String t) { }
            @Override public void onDiscoveryStopped(String t) { }
            @Override public void onStartDiscoveryFailed(String type, int code) {
                showForeground("Không tìm được cổng ghép đôi mDNS. Có thể nhập CỔNG MÃ trong thông báo.", true);
                stopDiscovery();
            }
            @Override public void onStopDiscoveryFailed(String type, int code) { }
            @Override public void onServiceLost(NsdServiceInfo info) { }
            @Override public void onServiceFound(NsdServiceInfo service) {
                if (!service.getServiceType().contains("_adb-tls-pairing")) return;
                try {
                    nsd.resolveService(service, new NsdManager.ResolveListener() {
                        @Override public void onResolveFailed(NsdServiceInfo info, int error) { }
                        @Override public void onServiceResolved(NsdServiceInfo info) {
                            int port = info.getPort();
                            if (port < 1024 || port > 65535 || !active) return;
                            String resolved = info.getHost() == null ? "" : info.getHost().getHostAddress();
                            // Never blindly pair to a nearby device discovered on the same LAN.
                            if (!wifiIp.isEmpty() && !resolved.isEmpty() && !resolved.equals(wifiIp)) return;
                            pairingPort = port;
                            showForeground("Đã tìm cổng ghép đôi " + port + ". Nhập mã 6 số vào thông báo.", true);
                            if (queuedCode != null) {
                                String code = queuedCode;
                                queuedCode = null;
                                tryPair(wifiIp, port, code);
                            }
                        }
                    });
                } catch (Exception e) { Log.w("LocalADBPair", "mDNS resolve failed", e); }
            }
        };
        try { nsd.discoverServices("_adb-tls-pairing._tcp.", NsdManager.PROTOCOL_DNS_SD, discovery); }
        catch (Exception e) { Log.w("LocalADBPair", "mDNS start failed", e); }
    }

    private void stopDiscovery() {
        if (nsd != null && discovery != null) {
            try { nsd.stopServiceDiscovery(discovery); } catch (Exception ignored) { }
            discovery = null;
        }
        try { if (multicastLock != null && multicastLock.isHeld()) multicastLock.release(); }
        catch (Exception ignored) { }
    }

    private synchronized void tryPair(String host, int port, String code) {
        if (!active || busy) return;
        if (host == null || !host.matches("[0-9.]{7,15}") || port < 1024 || port > 65535
                || code == null || !code.matches("[0-9]{6}")) {
            showForeground("IP / cổng / mã không hợp lệ. Kiểm tra lại Gỡ lỗi không dây.", true);
            return;
        }
        busy = true;
        // Never persist the pairing code, even in the log.
        prefs(this).edit().remove("capture_until").apply();
        showForeground("Đang ghép đôi ADB " + host + ":" + port + "…", false);
        worker.execute(() -> {
            try {
                AdbBridge adb = AdbBridge.get();
                boolean paired = adb.pairLocal(host, port, code);
                if (!paired) throw new IllegalStateException("ADB từ chối ghép đôi. Kiểm tra mã hoặc tạo mã mới.");
                prefs(this).edit().putBoolean("ever_paired", true).putString("host", host).apply();
                showForeground("Ghép đôi thành công! Đang dò cổng kết nối ADB…", false);
                boolean connected = false;
                Exception error = null;
                for (int attempt = 0; attempt < 2 && !connected; attempt++) {
                    try { connected = adb.discoverAndConnect(getApplicationContext()) || adb.isConnected(); }
                    catch (Exception e) { error = e; }
                    if (!connected) SystemClock.sleep(1200);
                }
                if (!connected) {
                    int savedPort = prefs(this).getInt("connect_port", -1);
                    if (savedPort >= 1024 && savedPort <= 65535 && savedPort != port) {
                        try { connected = adb.connectLocal(host, savedPort) || adb.isConnected(); }
                        catch (Exception e) { Log.w("LocalADBPair", "Cached connection port failed", e); }
                    }
                }
                if (connected) finishWithMessage("Đã ghép đôi và kết nối ADB thành công. Quay lại ứng dụng.");
                else finishWithMessage("Ghép đôi thành công, chưa tự kết nối. Mở app → Tự tìm cổng và kết nối.");
            } catch (Exception e) {
                Log.w("LocalADBPair", "ADB pairing failed: " + e.getClass().getSimpleName());
                finishWithMessage("Ghép đôi lỗi: " + e.getClass().getSimpleName()
                        + ". Hãy mở mã mới và thử lại.");
            } finally {
                busy = false;
                stopDiscovery();
                active = false;
                stopForeground(STOP_FOREGROUND_DETACH);
                stopSelf();
            }
        });
    }

    private void finishWithMessage(String status) {
        active = false;
        showForeground(status, false);
    }

    private void showForeground(String status, boolean withReply) {
        Notification.Builder builder = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("Local ADB Manager · Ghép đôi")
                .setContentText(status)
                .setStyle(new Notification.BigTextStyle().bigText(status))
                .setOngoing(active)
                .setVisibility(Notification.VISIBILITY_SECRET)
                .setOnlyAlertOnce(true);
        Intent back = new Intent(this, MainActivity.class);
        PendingIntent open = PendingIntent.getActivity(this, 11, back,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        builder.setContentIntent(open);
        if (withReply) {
            Intent replyIntent = new Intent(this, PairingService.class).setAction(ACTION_REPLY);
            PendingIntent replyPi = PendingIntent.getService(this, 12, replyIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
            RemoteInput reply = new RemoteInput.Builder(EXTRA_REPLY)
                    .setLabel("Mã 6 số hoặc CỔNG MÃ").build();
            Notification.Action replyAction = new Notification.Action.Builder(
                    android.R.drawable.ic_menu_send, "Nhập mã ghép đôi", replyPi)
                    .addRemoteInput(reply).build();
            builder.addAction(replyAction);
            Intent stopIntent = new Intent(this, PairingService.class).setAction(ACTION_STOP);
            PendingIntent stopPi = PendingIntent.getService(this, 13, stopIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(new Notification.Action.Builder(
                    android.R.drawable.ic_menu_close_clear_cancel, "Dừng", stopPi).build());
        }
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, builder.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        else startForeground(ID, builder.build());
    }

    @Override public void onDestroy() {
        prefs(this).edit().remove("capture_until").apply();
        active = false;
        stopDiscovery();
        worker.shutdownNow();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
