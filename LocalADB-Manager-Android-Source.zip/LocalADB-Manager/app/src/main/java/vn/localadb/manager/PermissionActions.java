package vn.localadb.manager;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Android AppOps controllable by the ADB shell on some Android versions/ROMs. */
public final class PermissionActions {
    private PermissionActions() {}
    public static final List<String> ALLOWED_OPS = Collections.unmodifiableList(Arrays.asList(
            "REQUEST_INSTALL_PACKAGES", "SYSTEM_ALERT_WINDOW", "WRITE_SETTINGS",
            "GET_USAGE_STATS", "MANAGE_EXTERNAL_STORAGE", "RUN_IN_BACKGROUND",
            "RUN_ANY_IN_BACKGROUND", "AUTO_REVOKE_PERMISSIONS_IF_UNUSED"
    ));
    public static String title(String op) {
        switch (op) {
            case "REQUEST_INSTALL_PACKAGES": return "Cài ứng dụng không rõ nguồn";
            case "SYSTEM_ALERT_WINDOW": return "Hiển thị đè lên ứng dụng khác";
            case "WRITE_SETTINGS": return "Thay đổi cài đặt hệ thống";
            case "GET_USAGE_STATS": return "Truy cập dữ liệu sử dụng";
            case "MANAGE_EXTERNAL_STORAGE": return "Quản lý tất cả tệp";
            case "RUN_IN_BACKGROUND": return "Chạy trong nền";
            case "RUN_ANY_IN_BACKGROUND": return "Chạy nền không giới hạn";
            case "AUTO_REVOKE_PERMISSIONS_IF_UNUSED": return "Tự thu hồi quyền khi ít sử dụng";
            default: return op;
        }
    }
}
