package vn.localadb.manager;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.LinkAddress;
import android.net.Network;
import android.net.NetworkCapabilities;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ProgressBar;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Vietnamese, fully on-device app manager. No remote server, telemetry, or automatic
 * permission dialog clicks. Privileged changes need an authenticated local ADB connection.
 */
public class MainActivity extends Activity {
    private static final int BG = Color.rgb(16, 22, 34);
    private static final int CARD = Color.rgb(29, 40, 56);
    private static final int FG = Color.rgb(235, 241, 255);
    private static final int MUTED = Color.rgb(167, 180, 202);
    private static final int ACCENT = Color.rgb(117, 159, 255);
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ArrayList<AppItem> installed = new ArrayList<>();
    private final ArrayList<AppItem> visibleApps = new ArrayList<>();
    private final ArrayList<String> logs = new ArrayList<>();
    private LinearLayout root;
    private String page = "apps";
    private AppItem activeApp;
    private TextView connectionIndicator;
    private ListView appList;
    private ArrayAdapter<AppItem> appAdapter;
    private EditText searchField;
    private CheckBox includeSystem;
    private TextView countLabel;
    private EditText pairingPortField, connectionPortField, pairingCodeField, wifiIpField;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        addLog("Khởi chạy; Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        try { nsd = (NsdManager) getSystemService(Context.NSD_SERVICE); } catch (Exception ignored) {}
        loadApps();
        showApps();
    }

    @Override public void onBackPressed() {
        if (page.equals("detail")) showApps();
        else if (!page.equals("apps")) showApps();
        else super.onBackPressed();
    }

    @Override protected void onResume() {
        super.onResume();
        if (connectionIndicator != null) updateConnection();
    }

    @Override protected void onDestroy() {
        stopDiscovery();
        executor.shutdownNow();
        // Do not tear down the connection while a foreground pairing service is working.
        // The user can explicitly disconnect from the ADB page.
        super.onDestroy();
    }

    private void addLog(String s) {
        logs.add(DateFormat.getTimeInstance(DateFormat.SHORT, new Locale("vi", "VN")).format(new Date()) + "  " + s);
        if (logs.size() > 120) logs.remove(0);
    }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        return d;
    }
    private TextView text(String message, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(message); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private void spacer(LinearLayout parent, int height) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }
    private void add(LinearLayout parent, View view) {
        parent.addView(view, new LinearLayout.LayoutParams(-1, -2));
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private LinearLayout panel(LinearLayout parent) {
        LinearLayout panel = vertical(); panel.setPadding(dp(14), dp(14), dp(14), dp(14));
        panel.setBackground(background(CARD, 14));
        parent.addView(panel, new LinearLayout.LayoutParams(-1, -2)); return panel;
    }
    private Button button(String text, Runnable onClick) {
        Button b = new Button(this);
        b.setAllCaps(false); b.setText(text); b.setTextSize(13); b.setTextColor(FG);
        b.setBackground(background(Color.rgb(54, 75, 112), 10));
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setOnClickListener(v -> onClick.run());
        return b;
    }
    private void action(LinearLayout group, String label, Runnable onClick) {
        add(group, button(label, onClick)); spacer(group, 7);
    }
    private void heading(LinearLayout group, String title, String summary) {
        add(group, text(title, 18, FG, true)); spacer(group, 5);
        if (summary != null) { add(group, text(summary, 12, MUTED, false)); spacer(group, 12); }
    }
    private EditText field(LinearLayout parent, String hint, String pref) {
        EditText input = new EditText(this);
        input.setSingleLine(true); input.setHint(hint);
        input.setTextColor(FG); input.setHintTextColor(MUTED);
        if (pref != null) input.setText(getPreferences(0).getString(pref, ""));
        input.setTextSize(14);
        add(parent, input); spacer(parent, 8);
        return input;
    }
    private void base(String location) {
        page = location;
        root = vertical(); root.setBackgroundColor(BG);
        root.setPadding(dp(15), dp(12), dp(15), dp(10));
        setContentView(root);
        TextView title = text("LOCAL ADB MANAGER", 20, FG, true);
        add(root, title); spacer(root, 5);
        connectionIndicator = text("ADB: đang kiểm tra…", 12, MUTED, false);
        add(root, connectionIndicator); updateConnection(); spacer(root, 12);
        LinearLayout nav = horizontal();
        addNav(nav, "Ứng dụng", "apps", this::showApps);
        addNav(nav, "ADB", "adb", this::showAdb);
        addNav(nav, "Nhật ký", "logs", this::showLog);
        add(root, nav); spacer(root, 13);
    }
    private void addNav(LinearLayout row, String name, String key, Runnable click) {
        Button b = button(name, click);
        if (key.equals(page)) b.setBackground(background(ACCENT, 10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1);
        lp.setMargins(dp(2), 0, dp(2), 0); row.addView(b, lp);
    }
    private void updateConnection() {
        if (connectionIndicator == null) return;
        boolean connected = false;
        try { connected = AdbBridge.get().isConnected(); } catch (Exception e) { addLog("Khởi tạo ADB: " + e.getMessage()); }
        connectionIndicator.setText(connected ? "● ADB cục bộ đã kết nối" : "○ Chưa kết nối ADB — quét app vẫn hoạt động");
        connectionIndicator.setTextColor(connected ? Color.rgb(131, 224, 177) : MUTED);
    }
    private interface Work { String run() throws Exception; }
    private void work(String description, Work task) {
        toast("Đang thực hiện: " + description);
        executor.execute(() -> {
            String outcome;
            boolean success = true;
            try { outcome = task.run(); }
            catch (Exception e) { success = false; outcome = e.getClass().getSimpleName() + ": " + e.getMessage(); }
            final String msg = outcome;
            final boolean good = success;
            runOnUiThread(() -> {
                addLog((good ? "✓ " : "✗ ") + description + ": " + msg);
                updateConnection();
                new AlertDialog.Builder(this).setTitle(good ? "Kết quả" : "Không thực hiện được")
                        .setMessage(msg).setPositiveButton("Đóng", null).show();
            });
        });
    }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private void confirm(String title, String message, Runnable run) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message)
                .setNegativeButton("Hủy", null).setPositiveButton("Xác nhận", (d,w) -> run.run()).show();
    }
    private void open(Intent intent) {
        try { startActivity(intent); }
        catch (ActivityNotFoundException e) { toast("ROM không hỗ trợ trang cài đặt này"); }
        catch (Exception e) { toast("Không thể mở: " + e.getMessage()); }
    }
    private void openAppDetails(String pkg) {
        open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + pkg)));
    }
    private void openSpecialSettings(String action, String pkg) {
        try { startActivity(new Intent(action, Uri.parse("package:" + pkg))); }
        catch (Exception e) { openAppDetails(pkg); }
    }

    private void loadApps() {
        installed.clear();
        PackageManager pm = getPackageManager();
        List<PackageInfo> all;
        if (Build.VERSION.SDK_INT >= 33)
            all = pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS));
        else all = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS);
        for (PackageInfo info : all) {
            try {
                ApplicationInfo ai = info.applicationInfo;
                if (ai == null) continue;
                String label = String.valueOf(pm.getApplicationLabel(ai));
                installed.add(new AppItem(label, info, ai));
            } catch (Exception ignored) {}
        }
        Collections.sort(installed, (a,b) -> a.label.compareToIgnoreCase(b.label));
        addLog("Quét được " + installed.size() + " ứng dụng");
    }
    private static final class AppItem {
        final String label; final PackageInfo info; final ApplicationInfo ai;
        AppItem(String label, PackageInfo info, ApplicationInfo ai) {
            this.label = label; this.info = info; this.ai = ai;
        }
        boolean system() { return (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0; }
        @Override public String toString() {
            return label + "\n" + info.packageName + (system() ? "  · Hệ thống" : "");
        }
    }
    private void applyFilter() {
        if (appAdapter == null || searchField == null || includeSystem == null) return;
        String term = searchField.getText().toString().toLowerCase(Locale.ROOT).trim();
        visibleApps.clear();
        for (AppItem app : installed) {
            if (!includeSystem.isChecked() && app.system()) continue;
            if (!term.isEmpty() && !app.label.toLowerCase(Locale.ROOT).contains(term)
                    && !app.info.packageName.toLowerCase(Locale.ROOT).contains(term)) continue;
            visibleApps.add(app);
        }
        appAdapter.clear(); appAdapter.addAll(visibleApps); appAdapter.notifyDataSetChanged();
        countLabel.setText("Đang hiển thị " + visibleApps.size() + " / " + installed.size() + " ứng dụng");
    }
    private void showApps() {
        base("apps"); activeApp = null;
        LinearLayout tools = panel(root);
        heading(tools, "Quản lý ứng dụng", "Danh sách đọc trực tiếp từ PackageManager, không tải lên mạng.");
        searchField = field(tools, "Tìm theo tên ứng dụng hoặc package", null);
        includeSystem = new CheckBox(this); includeSystem.setText("Hiện cả ứng dụng hệ thống");
        includeSystem.setTextColor(FG); includeSystem.setChecked(false); add(tools, includeSystem);
        countLabel = text("Đang tải…", 12, MUTED, false); add(tools, countLabel);
        action(tools, "↻ Quét lại ứng dụng", () -> { loadApps(); applyFilter(); });
        spacer(root, 12);
        appList = new ListView(this);
        appList.setDividerHeight(dp(1)); appList.setCacheColorHint(Color.TRANSPARENT);
        appAdapter = new ArrayAdapter<AppItem>(this, android.R.layout.simple_list_item_1, new ArrayList<AppItem>()) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setTextColor(FG); t.setTextSize(14); t.setPadding(dp(13), dp(11), dp(10), dp(11));
                t.setMinHeight(dp(56)); return t;
            }
        };
        appList.setAdapter(appAdapter);
        appList.setOnItemClickListener((p, v, pos, id) -> {
            if (pos < visibleApps.size()) showDetail(visibleApps.get(pos));
        });
        root.addView(appList, new LinearLayout.LayoutParams(-1, 0, 1));
        includeSystem.setOnCheckedChangeListener((v, checked) -> applyFilter());
        searchField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int f) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { applyFilter(); }
            @Override public void afterTextChanged(Editable e) {}
        });
        applyFilter();
    }
    private void showDetail(AppItem app) {
        activeApp = app;
        base("detail");
        ScrollView scroll = new ScrollView(this); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout body = vertical(); scroll.addView(body);
        LinearLayout intro = panel(body);
        heading(intro, app.label, app.info.packageName + (app.system()? "\nỨng dụng hệ thống" : "\nỨng dụng người dùng"));
        action(intro, "← Trở về danh sách", this::showApps);
        action(intro, "Mở thông tin ứng dụng trong Cài đặt", () -> openAppDetails(app.info.packageName));
        action(intro, "Mở cài đặt thông báo", () -> {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, app.info.packageName);
            open(i);
        });
        action(intro, "Mở cài đặt pin / giới hạn chạy nền", () -> {
            openAppDetails(app.info.packageName);
            toast("Vào mục Pin / Battery trên trang của ứng dụng");
        });
        action(intro, "Mở cài đặt Truy cập tất cả tệp", () ->
                openSpecialSettings(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, app.info.packageName));
        spacer(body, 12);
        LinearLayout special = panel(body);
        heading(special, "Quyền đặc biệt / AppOps", "Chọn một quyền để xem trạng thái hoặc thay đổi bằng ADB. Tác dụng phụ thuộc Android và ROM Xiaomi.");
        for (String op : PermissionActions.ALLOWED_OPS) {
            action(special, PermissionActions.title(op) + "  ›", () -> showOpDialog(app, op));
        }
        spacer(body, 12);
        LinearLayout runtime = panel(body);
        String[] requested = app.info.requestedPermissions;
        heading(runtime, "Quyền runtime được ứng dụng yêu cầu",
                requested == null ? "Không khai báo quyền runtime" : "Tổng số quyền khai báo: " + requested.length + ". Chỉ quyền dạng dangerous mới có thể thử pm grant/revoke.");
        if (requested != null) {
            Arrays.sort(requested);
            for (String permission : requested) {
                boolean granted = getPackageManager().checkPermission(permission, app.info.packageName) == PackageManager.PERMISSION_GRANTED;
                boolean dangerous = isDangerous(permission);
                String suffix = granted ? "✓ Đã cấp" : "○ Chưa cấp";
                if (!dangerous) suffix += " · Không phải quyền runtime";
                String name = permission.replace("android.permission.", "");
                action(runtime, name + "  —  " + suffix, () -> showPermissionDialog(app, permission, dangerous));
            }
        }
        spacer(body, 20);
    }
    private boolean isDangerous(String permission) {
        try {
            PermissionInfo pi = getPackageManager().getPermissionInfo(permission, 0);
            return (pi.protectionLevel & PermissionInfo.PROTECTION_MASK_BASE) == PermissionInfo.PROTECTION_DANGEROUS;
        } catch (Exception ex) { return false; }
    }
    private void showPermissionDialog(AppItem app, String permission, boolean dangerous) {
        boolean granted = getPackageManager().checkPermission(permission, app.info.packageName) == PackageManager.PERMISSION_GRANTED;
        List<String> choices = new ArrayList<>();
        choices.add("Mở Cài đặt ứng dụng");
        if (dangerous) { choices.add("Cấp bằng ADB (pm grant)"); choices.add("Thu hồi bằng ADB (pm revoke)"); }
        new AlertDialog.Builder(this).setTitle(permission)
                .setMessage("Trạng thái hiện tại: " + (granted?"Đã cấp":"Chưa cấp")
                        + "\n" + (dangerous?"Quyền runtime — ứng dụng phải khai báo quyền.":"Không thuộc nhóm runtime nguy hiểm có thể cấp bằng pm grant."))
                .setItems(choices.toArray(new String[0]), (d, selected) -> {
                    if (selected == 0) { openAppDetails(app.info.packageName); return; }
                    boolean grant = selected == 1;
                    confirm(grant?"Cấp quyền?":"Thu hồi quyền?", "Ứng dụng: " + app.label +
                            "\n"+permission+"\nADB có thể từ chối nếu quyền bị Android/OEM hạn chế."
                            + "\nChỉ tiếp tục nếu bạn tin tưởng ứng dụng này.", () -> {
                        work("pm " + (grant?"grant ":"revoke ") + app.info.packageName + " " + permission,
                                () -> {
                                    AdbBridge.CommandResult r = AdbBridge.get().runtimePermission(app.info.packageName, permission, grant);
                                    if (!r.success()) throw new IllegalStateException(r.toString());
                                    int result = getPackageManager().checkPermission(permission, app.info.packageName);
                                    return r + "\nTrạng thái kiểm tra lại: " + (result == PackageManager.PERMISSION_GRANTED ? "Đã cấp" : "Chưa cấp");
                                });
                    });
                }).setNegativeButton("Đóng", null).show();
    }
    private void showOpDialog(AppItem app, String op) {
        String pkg = app.info.packageName;
        String[] options = {"Kiểm tra trạng thái (ADB)", "Cho phép (allow)",
                "Chặn (ignore)", "Khôi phục mặc định (default)", "Mở Cài đặt ứng dụng"};
        new AlertDialog.Builder(this).setTitle(PermissionActions.title(op)).setMessage(pkg + "\nAppOp: " + op)
                .setItems(options, (d, which) -> {
                    if (which == 4) {
                        if (op.equals("REQUEST_INSTALL_PACKAGES"))
                            openSpecialSettings(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, pkg);
                        else if (op.equals("SYSTEM_ALERT_WINDOW"))
                            openSpecialSettings(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg);
                        else if (op.equals("WRITE_SETTINGS"))
                            openSpecialSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg);
                        else if (op.equals("GET_USAGE_STATS"))
                            open(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                        else openAppDetails(pkg);
                        return;
                    }
                    if (which == 0) {
                        work("Đọc AppOp " + pkg + "/" + op,
                                () -> AdbBridge.get().getAppOp(pkg, op).toString());
                        return;
                    }
                    String mode = which == 1 ? "allow" : which == 2 ? "ignore" : "default";
                    confirm("Đổi " + PermissionActions.title(op) + "?",
                            "Package: " + pkg + "\nChế độ mới: " + mode
                            + "\n\nĐây là thay đổi có thể tác động đến bảo mật hoặc cách ứng dụng hoạt động."
                            + "\nYêu cầu ADB đã ghép đôi. Bạn có thể hoàn tác bằng default.", () -> {
                        work("appops set " + pkg + " " + op + " " + mode, () -> {
                            AdbBridge.CommandResult set = AdbBridge.get().appOp(pkg, op, mode);
                            if (!set.success()) throw new IllegalStateException(set.toString());
                            AdbBridge.CommandResult verify = AdbBridge.get().getAppOp(pkg, op);
                            return "Lệnh: " + set + "\nĐọc lại AppOp: " + verify +
                                    "\nLưu ý: ROM có thể áp dụng hạn chế riêng; hãy kiểm tra lại trong Cài đặt.";
                        });
                    });
                }).setNegativeButton("Đóng", null).show();
    }
    private static int parsePort(String raw) {
        int p;
        try { p = Integer.parseInt(raw.trim()); }
        catch (NumberFormatException ex) { throw new IllegalArgumentException("Cổng phải là số"); }
        AdbBridge.checkPort(p); return p;
    }
    /** Prefer the Wi-Fi interface rather than hard-coded localhost. No root required. */
    private String findWifiIp() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                for (Network network : cm.getAllNetworks()) {
                    NetworkCapabilities capabilities = cm.getNetworkCapabilities(network);
                    if (capabilities == null || !capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue;
                    LinkProperties props = cm.getLinkProperties(network);
                    if (props == null) continue;
                    for (LinkAddress address : props.getLinkAddresses()) {
                        InetAddress ip = address.getAddress();
                        if (ip instanceof Inet4Address && !ip.isLoopbackAddress() && !ip.isLinkLocalAddress())
                            return ip.getHostAddress();
                    }
                }
            }
        } catch (Exception e) { addLog("Tìm IP qua ConnectivityManager: " + e.getMessage()); }
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces != null && interfaces.hasMoreElements()) {
                NetworkInterface ni = interfaces.nextElement();
                String name = ni.getName().toLowerCase(Locale.ROOT);
                if (!name.startsWith("wlan") && !name.startsWith("wifi")) continue;
                if (!ni.isUp()) continue;
                Enumeration<InetAddress> addresses = ni.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress ip = addresses.nextElement();
                    if (ip instanceof Inet4Address && !ip.isLoopbackAddress()) return ip.getHostAddress();
                }
            }
        } catch (Exception e) { addLog("Tìm IP từ Wi-Fi interface: " + e.getMessage()); }
        return "";
    }

    private String selectedWifiIp() {
        if (wifiIpField == null) throw new IllegalStateException("Chưa nhập địa chỉ IP Wi-Fi");
        String value = wifiIpField.getText().toString().trim();
        if (value.isEmpty()) throw new IllegalArgumentException("Nhập IP từ màn hình Gỡ lỗi không dây");
        return value;
    }


    private void beginBackgroundPairing() {
        final String host;
        try { host = selectedWifiIp(); }
        catch (Exception e) { toast(e.getMessage()); return; }
        getPreferences(0).edit().putString("wifi_host", host).apply();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 804);
            return;
        }
        try {
            PairingService.begin(this, host);
            toast("Đã mở thông báo ghép đôi. Giữ cửa sổ Cài đặt trên màn hình.");
            try { startActivity(new Intent("android.settings.WIRELESS_DEBUGGING_SETTINGS")); }
            catch (Exception e) { open(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
        } catch (Exception e) { toast("Không thể khởi động thông báo: " + e.getMessage()); }
    }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == 804) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
                beginBackgroundPairing();
            else toast("Cần cho phép thông báo để nhập mã ghép đôi mà không thoát Cài đặt.");
        }
    }

    private void showAdb() {
        base("adb");
        ScrollView scroll = new ScrollView(this); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout body = vertical(); scroll.addView(body);
        LinearLayout info = panel(body);
        heading(info, "Kết nối ADB ngay trên điện thoại", "Không cần máy tính. Bật Tùy chọn nhà phát triển > Gỡ lỗi không dây (Wireless debugging) trong Cài đặt. Kết nối này yêu cầu chính bạn phê duyệt ghép đôi.");
        action(info, "Mở trang Gỡ lỗi không dây", () -> {
            try { startActivity(new Intent("android.settings.WIRELESS_DEBUGGING_SETTINGS")); }
            catch (Exception e) { open(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
        });
        action(info, "Mở Tùy chọn nhà phát triển", () -> open(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)));
        heading(info, "IP Wi-Fi để ghép đôi/kết nối", "Lấy phần IP trước dấu : trên màn hình Gỡ lỗi không dây, ví dụ 192.168.1.159. KHÔNG nhập 127.0.0.1.");
        wifiIpField = field(info, "IP Wi-Fi (ví dụ: 192.168.1.159)", "wifi_host");
        if (wifiIpField.getText().toString().trim().isEmpty() || wifiIpField.getText().toString().startsWith("127.")) {
            wifiIpField.setText(findWifiIp());
        }
        action(info, "Tự lấy IP Wi-Fi từ điện thoại", () -> {
            String detected = findWifiIp();
            if (!detected.isEmpty()) {
                wifiIpField.setText(detected);
                toast("Đã tìm thấy IP: " + detected);
            } else toast("Không tìm được IP Wi-Fi; hãy nhập IP đang hiển thị trong Gỡ lỗi không dây");
        });
        spacer(body, 12);
        LinearLayout automatic = panel(body);
        heading(automatic, "Ghép đôi mà KHÔNG rời màn hình Cài đặt",
                "Bắt đầu từ đây, rồi trong Cài đặt chọn Gỡ lỗi không dây → Ghép đôi bằng mã."
                + "\n① Nếu bạn chủ động bật Accessibility, ứng dụng sẽ thử tự đọc mã và cổng trên Cài đặt."
                + "\n② Nếu Xiaomi không cho đọc, kéo thanh thông báo xuống → Nhập mã ghép đôi."
                + "\nKhông cần chuyển về Local ADB Manager. Mã không được lưu hoặc gửi đi.");
        action(automatic, "1. BẬT chế độ tự đọc mã (tùy chọn)", () ->
                new AlertDialog.Builder(this).setTitle("Quyền Accessibility")
                        .setMessage("Chỉ khi bạn bấm '2. Bắt đầu ghép đôi', dịch vụ thử đọc mã 6 số và IP:cổng"
                                + " trong trang Cài đặt Android, tối đa 10 phút. Không tự bấm cấp quyền,"
                                + " không lưu mã và không gửi ra Internet. Nếu Xiaomi không cho đọc,"
                                + " bạn vẫn có thể nhập mã qua thông báo. Sau khi dùng có thể tắt quyền này.")
                        .setNegativeButton("Hủy", null)
                        .setPositiveButton("Mở Trợ năng", (d, w) -> open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                        .show());
        action(automatic, "2. BẮT ĐẦU ghép đôi qua thông báo / tự đọc", this::beginBackgroundPairing);
        action(automatic, "Dừng ghép đôi / tắt tự đọc", () -> {
            PairingService.prefs(this).edit().remove("capture_until").apply();
            try { startService(new Intent(this, PairingService.class).setAction(PairingService.ACTION_STOP)); }
            catch (Exception ignored) {}
            toast("Đã dừng nhận mã ghép đôi");
        });
        spacer(body, 12);
        LinearLayout pair = panel(body);
        heading(pair, "1 · Ghép đôi ADB THỦ CÔNG (dự phòng)", "Nếu không dùng thông báo, có thể mở 2 ứng dụng dạng chia đôi màn hình để nhập mã.");
        pairingPortField = field(pair, "Cổng GHÉP ĐÔI (ví dụ: 38931)", "pair_port");
        pairingPortField.setInputType(2);
        pairingCodeField = field(pair, "Mã ghép đôi 6 số", null);
        pairingCodeField.setInputType(2);
        action(pair, "Dò cổng ghép đôi (mDNS)", this::discoverPairingPort);
        action(pair, "Ghép đôi bằng IP Wi-Fi", () -> {
            final int port;
            final String host;
            try { port = parsePort(pairingPortField.getText().toString()); host = selectedWifiIp(); }
            catch (Exception e) { toast(e.getMessage()); return; }
            final String code = pairingCodeField.getText().toString().trim();
            getPreferences(0).edit().putString("pair_port", "" + port).putString("wifi_host", host).apply();
            work("Ghép đôi ADB " + host + ":" + port, () ->
                    AdbBridge.get().pairLocal(host, port, code) ?
                    "Ghép đôi thành công. Nhập cổng KẾT NỐI ở màn hình Gỡ lỗi không dây hoặc bấm Tự tìm." :
                    "Ghép đôi không thành công. Kiểm tra mã mới, IP Wi-Fi và cổng GHÉP ĐÔI.");
        });
        spacer(body, 12);
        LinearLayout conn = panel(body);
        heading(conn, "2 · Kết nối ADB", "Cổng kết nối khác cổng ghép đôi! Nhìn địa chỉ IP:cổng ở màn hình Gỡ lỗi không dây, hoặc dùng tự dò.");
        connectionPortField = field(conn, "Cổng KẾT NỐI (ví dụ: 37111)", "connect_port");
        connectionPortField.setInputType(2);
        action(conn, "Tự tìm cổng và kết nối", () -> {
            final String host;
            final int manualPort;
            try {
                host = selectedWifiIp();
                String portText = connectionPortField.getText().toString().trim();
                manualPort = portText.isEmpty() ? -1 : parsePort(portText);
            } catch (Exception e) { toast(e.getMessage()); return; }
            work("Tự tìm ADB TLS", () -> {
                try {
                    boolean ok = AdbBridge.get().discoverAndConnect(getApplicationContext());
                    if (ok || AdbBridge.get().isConnected()) return "Đã kết nối qua mDNS.";
                } catch (Exception e) {
                    if (manualPort <= 0) throw new IllegalStateException(
                        "Tự dò mDNS thất bại: " + e.getMessage() + "\nHãy nhập cổng kết nối trên màn hình Gỡ lỗi không dây.", e);
                }
                if (manualPort > 0 && AdbBridge.get().connectLocal(host, manualPort))
                    return "Kết nối thành công bằng IP Wi-Fi: " + host + ":" + manualPort;
                if (AdbBridge.get().isConnected()) return "Đã kết nối ADB.";
                return "Chưa kết nối. Hãy kiểm tra ghép đôi và cổng kết nối, rồi thử thủ công.";
            });
        });
        action(conn, "Kết nối bằng IP và cổng thủ công", () -> {
            final int port;
            final String host;
            try { port = parsePort(connectionPortField.getText().toString()); host = selectedWifiIp(); }
            catch (Exception e) { toast(e.getMessage()); return; }
            getPreferences(0).edit().putString("connect_port", "" + port).putString("wifi_host", host).apply();
            work("Kết nối ADB " + host + ":" + port, () -> {
                boolean ok = AdbBridge.get().connectLocal(host, port);
                return ok || AdbBridge.get().isConnected() ? "Kết nối thành công." :
                     "Không kết nối được. Cần ghép đôi trước và nhập đúng cổng KẾT NỐI.";
            });
        });
        action(conn, "Kiểm tra quyền ADB (id)", () -> work("ADB identity", () -> AdbBridge.get().execute("id").toString()));
        action(conn, "Ngắt kết nối ADB", () -> work("Ngắt kết nối", () -> {
            AdbBridge.get().disconnect(); return "Đã ngắt kết nối.";
        }));
        spacer(body, 12);
        LinearLayout other = panel(body);
        heading(other, "Cài APK và quyền của chính ứng dụng này", "Việc cài đặt vẫn hiển thị xác nhận của Android. Không thể tự bấm chấp nhận hoặc tự cấp quyền đặc biệt trước khi ghép đôi.");
        action(other, "Cho phép Local ADB Manager cài APK (Cài đặt)", () ->
                openSpecialSettings(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, getPackageName()));
        action(other, "Chọn tệp APK và mở trình cài đặt", () -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("application/vnd.android.package-archive");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, 7001);
        });
        spacer(body, 14);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 7001 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            confirm("Cài tệp APK đã chọn?", "Android sẽ mở trình cài đặt hệ thống để bạn xác nhận."
                    + "\nChỉ cài ứng dụng từ nguồn đáng tin cậy.", () -> {
                Intent install = new Intent(Intent.ACTION_VIEW);
                install.setDataAndType(uri, "application/vnd.android.package-archive");
                install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                open(install);
            });
        }
    }
    private void discoverPairingPort() {
        if (nsd == null) { toast("Không có NsdManager trên ROM này"); return; }
        stopDiscovery();
        toast("Đang tìm dịch vụ _adb-tls-pairing._tcp...");
        discovery = new NsdManager.DiscoveryListener() {
            @Override public void onStartDiscoveryFailed(String t,int c) { runOnUiThread(() -> toast("Không tìm được mDNS: " + c)); stopDiscovery(); }
            @Override public void onStopDiscoveryFailed(String t,int c) { }
            @Override public void onDiscoveryStarted(String t) { }
            @Override public void onDiscoveryStopped(String t) { }
            @Override public void onServiceLost(NsdServiceInfo s) { }
            @Override public void onServiceFound(NsdServiceInfo service) {
                if (!service.getServiceType().contains("_adb-tls-pairing")) return;
                nsd.resolveService(service, new NsdManager.ResolveListener() {
                    @Override public void onResolveFailed(NsdServiceInfo s, int c) { }
                    @Override public void onServiceResolved(NsdServiceInfo result) {
                        runOnUiThread(() -> {
                            if (pairingPortField != null) pairingPortField.setText("" + result.getPort());
                            if (wifiIpField != null && result.getHost() != null
                                    && result.getHost() instanceof Inet4Address) {
                                wifiIpField.setText(result.getHost().getHostAddress());
                            }
                            toast("Đã dò mDNS: " + result.getPort());
                            stopDiscovery();
                        });
                    }
                });
            }
        };
        try { nsd.discoverServices("_adb-tls-pairing._tcp.", NsdManager.PROTOCOL_DNS_SD, discovery); }
        catch (Exception e) { toast("mDNS không hoạt động: " + e.getMessage()); }
    }
    private void stopDiscovery() {
        if (nsd != null && discovery != null) {
            try { nsd.stopServiceDiscovery(discovery); } catch (Exception ignored) {}
            discovery = null;
        }
    }
    private void showLog() {
        base("logs");
        LinearLayout body = panel(root);
        heading(body, "Nhật ký (chỉ lưu trong phiên)", "Không gửi dữ liệu ra máy chủ nào. Nhật ký không tự lưu vào tệp.");
        action(body, "Xóa nhật ký", () -> { logs.clear(); showLog(); });
        ScrollView scroll = new ScrollView(this);
        TextView list = text(android.text.TextUtils.join("\n\n", logs), 12, FG, false);
        list.setTextIsSelectable(true); list.setPadding(dp(8),dp(8),dp(8),dp(8));
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
    }
}
