package vn.localadb.manager;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Opt-in, time-limited pairing-code reader. Only examines Android Settings. */
public final class PairingAccessibilityService extends AccessibilityService {
    private static final Pattern CODE = Pattern.compile("(?<![0-9])([0-9]{6})(?![0-9])");
    private static final Pattern ADDRESS = Pattern.compile("(?<![0-9])((?:[0-9]{1,3}\\.){3}[0-9]{1,3}):([0-9]{4,5})(?![0-9])");
    private String lastAttempt = "";

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || !PairingService.isArmed(this)) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null || !"com.android.settings".contentEquals(pkg)) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        List<String> pieces = new ArrayList<>();
        gatherText(root, pieces, 0);
        String screen = android.text.TextUtils.join("\n", pieces);
        String normalized = screen.toLowerCase(Locale.ROOT);
        // On the Wireless debugging Settings page, record ONLY the ADB connection
        // port from the explicitly opened page for use after pairing. This is not
        // the short-lived PAIRING port in the pop-up window.
        String expectedHost = PairingService.prefs(this).getString("host", "");
        if ((normalized.contains("wireless debugging") || normalized.contains("gỡ lỗi không dây"))
                && (normalized.contains("ip address & port") || normalized.contains("địa chỉ ip"))) {
            Matcher connectionAddresses = ADDRESS.matcher(screen);
            if (connectionAddresses.find() && expectedHost.equals(connectionAddresses.group(1))) {
                int connectionPort = Integer.parseInt(connectionAddresses.group(2));
                if (connectionPort >= 1024 && connectionPort <= 65535)
                    PairingService.prefs(this).edit().putInt("connect_port", connectionPort).apply();
            }
        }
        // Do not inspect/send the six-digit number unless the pairing dialog is visible.
        if (!(normalized.contains("wlan pairing code") || normalized.contains("mã ghép đôi")
                || normalized.contains("pair with device") || normalized.contains("ghép đôi với thiết bị"))) return;
        Matcher codeMatches = CODE.matcher(screen);
        String code = null;
        while (codeMatches.find()) code = codeMatches.group(1);
        Matcher addresses = ADDRESS.matcher(screen);
        String host = null;
        int port = -1;
        // The pairing popup's IP:port is normally the last address on the screen.
        while (addresses.find()) {
            host = addresses.group(1);
            try { port = Integer.parseInt(addresses.group(2)); }
            catch (NumberFormatException ignored) { port = -1; }
        }
        if (code == null || host == null || port < 1024 || port > 65535) return;
        if (!host.equals(expectedHost)) return;
        String key = host + ":" + port + ":" + code;
        if (key.equals(lastAttempt)) return;
        lastAttempt = key;
        PairingService.submitFromAccessibility(this, host, port, code);
    }

    private void gatherText(AccessibilityNodeInfo node, List<String> lines, int depth) {
        if (node == null || depth > 28 || lines.size() > 250) return;
        if (node.getText() != null) lines.add(node.getText().toString());
        if (node.getContentDescription() != null) lines.add(node.getContentDescription().toString());
        for (int i = 0, n = node.getChildCount(); i < n; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                gatherText(child, lines, depth + 1);
                child.recycle();
            }
        }
    }
    @Override public void onInterrupt() { }
}
