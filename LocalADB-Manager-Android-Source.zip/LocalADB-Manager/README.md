**Update v1.0.2**: IP Wi-Fi thay vì 127.0.0.1 cho ADB pair/connect; xem FIX_WIFI_ADB.md.

# Build và cài đặt APK

Xem [BUILD_APK_GUIDE.md](BUILD_APK_GUIDE.md). Trạng thái: **chưa biên dịch APK**, chỉ có mã nguồn được kiểm tra cú pháp.

# Local ADB Manager — Android (tiếng Việt)

**Trạng thái: dự án mã nguồn mẫu, chưa build/chưa kiểm thử trên máy thật.** Không có tệp APK đã biên dịch trong bộ này. Cấu hình CI cho phép người dùng tạo tệp APK để cài trên điện thoại của chính mình.

## Tính năng đã viết

- Quét toàn bộ ứng dụng cài đặt bằng PackageManager (`QUERY_ALL_PACKAGES`), lọc app hệ thống, tìm tên/package.
- Xem quyền ứng dụng yêu cầu và trạng thái hiện tại; thử cấp/thu hồi **quyền runtime dangerous** bằng `pm grant`/`pm revoke` sau khi ghép đôi ADB.
- Xem/đổi AppOps cho ứng dụng đã chọn; mỗi lần thay đổi có hộp xác nhận; có `allow`, `ignore`, `default` để hoàn tác.
- AppOps: `REQUEST_INSTALL_PACKAGES`, `SYSTEM_ALERT_WINDOW`, `WRITE_SETTINGS`, `GET_USAGE_STATS`, `MANAGE_EXTERNAL_STORAGE`, `RUN_IN_BACKGROUND`, `RUN_ANY_IN_BACKGROUND`, `AUTO_REVOKE_PERMISSIONS_IF_UNUSED`.
- ADB không dây **ngay trên máy**: ghép đôi bằng mã 6 số và cổng; tìm cổng ghép đôi qua mDNS (nếu ROM hỗ trợ); tự dò cổng kết nối hoặc nhập thủ công; kiểm tra `id`, ngắt kết nối.
- Mở màn hình Cài đặt phù hợp khi không thể cấp quyền qua ADB. Có thể chọn một tệp APK bằng trình chọn tệp của Android và mở trình cài đặt hệ thống.
- Nhật ký ngay trong phiên. Không có server riêng, không gửi danh sách ứng dụng đi đâu.
- Chỉ dùng lệnh ADB theo danh sách chức năng, không có terminal nhập lệnh tuỳ ý. Dùng Android Keystore lưu khoá ADB.

## Xuất APK bằng GitHub Actions (không cần máy tính nếu dùng trình duyệt điện thoại)

1. Tạo một repository GitHub **riêng tư**. Giải nén dự án, tải toàn bộ các tệp lên repository, giữ nguyên cấu trúc `.github/workflows/build-apk.yml`.
2. Vào tab **Actions** → **Build Android APK** → **Run workflow** (nếu GitHub yêu cầu, kích hoạt Actions cho repository).
3. Sau khi workflow chạy **thành công**, mở phần **Artifacts**, tải `LocalADBManager-debug-apk`, giải nén và lấy `app-debug.apk`.
4. Trên điện thoại, mở `app-debug.apk` để cài. Chỉ cài gói APK được tạo bởi workflow thuộc repository của bạn.

Nếu dùng Android Studio: mở thư mục dự án; để Studio đồng bộ Gradle, rồi **Build → Build APK(s)**. Máy build cần JDK 17, Android SDK Platform 35, Gradle 8.9, mạng Internet để tải phụ thuộc. Lệnh tương đương: `gradle :app:assembleDebug`. Dự án chủ động không kèm Gradle wrapper binary; CI tải bản Gradle xác định.

## Thiết lập ADB trên điện thoại Android 11+

1. Bật **Tùy chọn nhà phát triển** và **Gỡ lỗi không dây (Wireless debugging)** trong Cài đặt. Kết nối Wi-Fi nếu ROM yêu cầu.
2. Trong Gỡ lỗi không dây, chọn **Ghép đôi thiết bị bằng mã ghép đôi**. Mã 6 số và **cổng ghép đôi** xuất hiện ở màn hình này.
3. Mở `Local ADB Manager` (có thể dùng chia đôi màn hình hoặc cửa sổ nổi để giữ mã ghép đôi hiển thị). Vào **ADB** → nhập **cổng ghép đôi** và mã → **Ghép đôi trên 127.0.0.1**.
4. Sau khi ghép đôi, quay về trang Gỡ lỗi không dây, nhìn **địa chỉ IP & cổng kết nối** (cổng này thường KHÁC cổng ghép đôi). Nhập **cổng kết nối** vào ứng dụng → **Kết nối bằng cổng thủ công**; hoặc bấm **Tự tìm cổng và kết nối**.
5. Dùng **Kiểm tra quyền ADB (id)**; thường hiển thị `uid=2000(shell)`.
6. Chuyển sang tab **Ứng dụng**, chọn app và quyền mong muốn; kiểm tra kết quả sau khi thao tác.

## Giới hạn bắt buộc / bảo mật

- Không có APK nào có thể **tự ý kích hoạt quyền ADB trước khi người dùng bật Gỡ lỗi không dây và ghép đôi**. Không thể tự nhấn “Chấp nhận” trên các hộp thoại được Android bảo vệ; không thể cấp một số quyền `signature`, `privileged`, vai trò thiết bị hoặc quyền do Xiaomi chặn nếu không có root / quản trị hệ thống thích hợp.
- `pm grant` chỉ hữu ích khi quyền thuộc loại runtime phù hợp và **ứng dụng đích đã khai báo** quyền đó. Nhiều quyền AppOps có thể đặt nhưng vẫn không có hiệu lực do yêu cầu chính sách bổ sung, target SDK, trạng thái ứng dụng, cài đặt bảo vệ của ROM.
- Riêng cài APK không rõ nguồn: Android 8+ dùng quyền **theo từng ứng dụng**; thử `appops set <package> REQUEST_INSTALL_PACKAGES allow` qua ADB có thể hiệu quả ở một số bản Android/ROM, nhưng không được bảo đảm. Hãy dùng trang **Cài đặt > Cài ứng dụng không rõ nguồn gốc** nếu trạng thái không đổi.
- Trên Android 13 trở lên có thêm rào cản “restricted settings” đối với một số quyền. ADB không đồng nghĩa root.
- Chạy ADB tăng đáng kể quyền quản trị thiết bị. **Tắt Gỡ lỗi không dây sau khi sử dụng**; chỉ ghép đôi với ứng dụng/khóa bạn tin tưởng; thu hồi thiết bị đã ghép đôi nếu không còn dùng.
- Dự án yêu cầu `QUERY_ALL_PACKAGES` cho đúng chức năng quản lý ứng dụng. Nếu phát hành qua Google Play, cần thỏa mãn chính sách khai báo quyền nhạy cảm của Play Console.
- **Chưa kiểm thử thực tế trên Xiaomi Mi 10S/MIUI**; các nút mDNS hoặc điều khiển AppOps phụ thuộc ROM.

## Thư viện / nguồn tham khảo

- [libadb-android (MuntashirAkon)](https://github.com/MuntashirAkon/libadb-android), bản JitPack 3.1.1, dual license Apache-2.0 / GPL-3.0-or-later.
- [Android Debug Bridge: kết nối không dây](https://developer.android.com/tools/adb).
- [Package visibility](https://developer.android.com/training/package-visibility/declaring).
- [Android special app access / install unknown apps](https://developer.android.com/reference/android/provider/Settings#ACTION_MANAGE_UNKNOWN_APP_SOURCES).

*Lưu ý: mã nguồn là điểm xuất phát để build và kiểm thử; chưa nên sử dụng để thay đổi hàng loạt quyền quan trọng khi chưa thử kỹ trên ROM của bạn.*
